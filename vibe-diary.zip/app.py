
import streamlit as st
import openai
import random
from textblob import TextBlob

st.set_page_config(page_title="Vibe Diary", page_icon="📝", layout="centered")

st.title("📝 Vibe Diary – The Journaling Bot That Feels You")
st.caption("Hackathon Edition | Built with 💖 & OpenAI")

openai.api_key = st.secrets["OPENAI_API_KEY"]

def analyze_emotion(text):
    blob = TextBlob(text)
    polarity = blob.sentiment.polarity
    if polarity > 0.3:
        return "positive"
    elif polarity < -0.3:
        return "negative"
    else:
        return "neutral"

def get_ai_response(prompt, mood):
    vibe_tone = {
        "positive": "You’re a cheerful best friend hyping them up.",
        "negative": "You’re a supportive best friend giving emotional comfort.",
        "neutral": "You’re a chill best friend keeping the vibe light."
    }
    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[
            {"role": "system", "content": f"You are a journaling buddy. {vibe_tone[mood]}"},
            {"role": "user", "content": prompt},
        ]
    )
    return response.choices[0].message.content.strip()

def get_recommendation(mood):
    quotes = {
        "positive": ["You’re glowing, bestie! ✨", "Keep that energy up 💃", "Let joy be your fuel. 🔥"],
        "negative": ["It’s okay to fall apart sometimes. 🩷", "Cry it out. I’m here. 🐸☔", "Take a breath. You’re doing your best."],
        "neutral": ["Let's vibe in the in-between 🌫️", "Not too sad, not too glad — just real 🌀"]
    }
    return random.choice(quotes[mood])

user_input = st.text_area("Write your journal entry here:", height=200, placeholder="What's on your mind today?")

if st.button("Analyze & Reply"):
    if user_input.strip() != "":
        with st.spinner("Feeling your vibes... 🎧"):
            mood = analyze_emotion(user_input)
            reply = get_ai_response(user_input, mood)
            reco = get_recommendation(mood)

        st.success("Here's your vibe check!")
        st.subheader("💬 AI Reply")
        st.write(reply)

        st.subheader("🎁 Vibe Boost")
        st.info(reco)

        st.balloons()
    else:
        st.warning("Bestie, you gotta type something first! 📝")

with st.expander("🎙️ Voice Journaling (Coming Soon)"):
    st.write("Voice input feature is on our roadmap. Stay tuned!")
